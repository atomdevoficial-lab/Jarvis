# Jarvis IA — NVIDIA API

Assistente web leve em Node.js/Express com **interface 100% por voz**. A tela é só o **núcleo neural**: uma esfera 3D de partículas em tela cheia, no topo de tudo, sem cabeçalho, sem chat, sem caixa de texto e sem botão. Abaixo dela, uma **legenda** mostra o que você está falando (transcrição ao vivo) e o que a Jarvis respondeu (texto da fala). A resposta é lida em voz alta com timbre grave de mordomo, e o servidor guarda a **memória de raciocínio por 7 dias**.

## Requisitos
- Node.js 18 ou superior
- Uma chave NVIDIA API válida configurada como variável de ambiente `NVIDIA_API_KEY`
- Microfone e navegador compatível (Chrome ou Edge recomendados)

## Executar localmente
1. Instale as dependências: `npm install`
2. Configure `NVIDIA_API_KEY` no ambiente (não coloque a chave no frontend ou em arquivos enviados publicamente).
3. Execute `npm start` e abra `http://localhost:8080`.

## Acionamento (sempre ativo, sem botão)
Ao abrir a página a escuta começa sozinha — o navegador pede a permissão do microfone uma única vez.
1. Abra o site por HTTPS (ou `localhost` durante desenvolvimento).
2. Permita o acesso ao microfone quando o navegador solicitar.
3. Diga **“Jarvis”** (em seguida fale o comando) **ou bata palmas duas vezes** e fale.
4. O que você disse aparece na legenda em tempo real; a resposta aparece na mesma legenda e é falada em voz alta.

As duas palmas precisam acontecer juntas (menos de 1 s de intervalo), com um intervalo de 2,5 s entre ativações. Sem microfone ou sem permissão, a página mostra o motivo na legenda — não existe botão de reserva.

### Anti-eco (a Jarvis não se ouve)
Enquanto a Jarvis fala, o que o microfone captar é **descartado**: o texto reconhecido é comparado com o trecho em reprodução e tratado como eco. É isso que encerra o ciclo de “mensagem infinita” (microfone ouvindo o próprio TTS). Se o que você falar **não** for eco, a síntese é cancelada na hora e a Jarvis passa a ouvir — interrupção natural, sem precisar esperar. A esfera neural também fica muda durante a fala (o provedor de áudio retorna `null`) e a detecção de palmas é suspensa, para uma “palma” falsa não reabrir o ciclo.

Observação: navegadores móveis podem suspender o microfone quando a aba fica em segundo plano ou a tela é bloqueada. A detecção de palmas depende do microfone/ambiente e pode precisar de calibração.

## Núcleo neural visual (esfera reativa)
A tela é preta com grade sutil e a esfera é desenhada em tempo real (`public/jarvis-core.js`) por partículas luminosas e milhares de linhas finas — no topo de tudo (`z-index` máximo) e ocupando boa parte da tela. A esfera não é um vídeo nem um GIF: a geometria é gerada por ruído 3D (irregular, com densidades diferentes) e animada a cada quadro.

A animação segue **o estado real do assistente** — nunca indica que está escutando com o microfone desligado:

| Estado | Quando acontece | Comportamento visual |
|---|---|---|
| `idle` — aguardando próximo comando | Sem atividade | Giro lento, cintilação suave, microfone (se ligado) dá uma reação discreta |
| `listening` — escutando | Palavra-chave/palmas detectadas ou fala real no microfone sempre ativo | Vibra e expande/contrai conforme o **volume capturado** |
| `processing` — processando | Comando enviado à API NVIDIA | Contração, giro rápido, ondas internas e pulsos percorrendo as conexões |
| `speaking` — respondendo | Streaming da resposta / síntese de voz em reprodução | Movimentos sincronizados com a fala, até a resposta terminar |

O rótulo de estado fica **acima** da esfera e a legenda da fala, **abaixo** — nenhum deles disputa espaço com a rede neural.

Detalhes técnicos:
- **Sem dependências externas**: Canvas 2D + projeção 3D manual (não usa Three.js nem CDN).
- **Áudio real**: Web Audio API (`AnalyserNode`) lê o RMS do microfone sempre ativo; a esfera só entra em `listening` com áudio de verdade (nunca inventa movimento).
- **Síntese de voz**: a reação é sincronizada pelos eventos `boundary` (palavra a palavra) do `speechSynthesis`, que é o timing real do áudio do TTS. Se o navegador não emitir `boundary`, a esfera mantém apenas o movimento orgânico do estado "respondendo" — nada é simulado.
- **Desempanho**: mais partículas em máquinas com mais núcleos (até ~950), escala de renderização (DPR) limitada e ajuste automático — se a taxa de quadros cair, o núcleo reduz partículas e volta a aumentar quando sobrar desempenho.
- A legenda (`#legenda`) é a única interface de texto: transcrição ao vivo, respostas e avisos de erro (permissão negada, API fora do ar etc.).

Ajustes rápidos em `public/jarvis-core.js`: `STATES` (giro, contração, brilho e pulsos por estado), `baseCount` (partículas) e `buildEdges()` (vizinhos e cordas). Ao editar o arquivo, atualize a versão em `<script src="/jarvis-core.js?v=...">` para limpar o cache do navegador.

## Voz de mordomo
`escolherVoz()` pontua as vozes disponíveis do navegador e escolhe a melhor (masculinas e naturais em primeiro lugar, sempre em português), e a fala é ajustada para `pitch 0.55` e `rate 0.9` — mais grave e pausada. A resposta é fatiada em frases curtas antes de ser falada, para a cadência não soar apressada. Um watchdog por trecho impede que o sintetizador trave a tela.

## Raciocínio e memória
O servidor grava as conversas em `data/memoria.json` e injeta os turnos antigos no prompt **antes** do histórico da sessão atual — é isso que evita o “Desculpe, não tenho memória de interações passadas” quando você recarrega a página ou volta no dia seguinte.

- **Raciocínio**: `NVIDIA_REASONING_EFFORT=high` (padrão) faz o modelo pensar em mais passos, revisar a própria conclusão e só então responder; `max_tokens: 4096` dá folga para essas respostas. `medium`/`low` deixam a resposta mais rápida e barata.
- **Retenção**: 7 dias (`MEMORIA_DIAS`), teto de 1000 turnos; os 24 turnos mais recentes entram no contexto de cada pergunta.
- **Apagar**: fale “deletar raciocínio”, “apagar memória” ou “limpar histórico”. O cliente intercepta o pedido, limpa na hora e responde sem chamar a IA. Por HTTP: `POST /api/memoria/clear` (consulta: `GET /api/memoria`).
- **Limitação de hospedagem**: o arquivo vive dentro do container — um novo deploy ou a parada da instância zera a memória (a Square Cloud não mantém volume persistente).

## Variáveis de ambiente
- `NVIDIA_API_KEY` — obrigatória, configure no painel da hospedagem
- `NVIDIA_MODEL` — padrão `openai/gpt-oss-20b`
- `NVIDIA_REASONING_EFFORT` — padrão `high` (`low` | `medium` | `high`)
- `MEMORIA_DIAS` — padrão `7` (retenção da memória de raciocínio)
- `PORT` — apenas para local (`8080`). **Não defina na Square Cloud**: a plataforma já usa `80` + `HOST=0.0.0.0`

## Segurança
Não publique nem compartilhe sua chave NVIDIA. Se uma chave real já esteve no código ou num ZIP enviado, revogue-a e gere outra. O servidor retorna erro explícito se a variável estiver ausente.

## Limitações atuais
Este projeto ainda é um assistente de voz. Ele não executa automaticamente comandos do sistema nem controla o OpenCode. Para isso, será necessário adicionar um agente local autenticado no computador Windows, com permissões limitadas e confirmação para ações destrutivas.
