const express = require('express');
const https = require('https');
const path = require('path');
const fs = require('fs');

// Square Cloud: o balanceador só encaminha tráfego externo para 0.0.0.0:80, e a
// plataforma define PORT=80 / HOST=0.0.0.0 por padrão (não devem ser sobrescritos).
// Em desenvolvimento local (Windows) usamos 8080, pois a porta 80 exige admin.
const IS_WINDOWS = process.platform === 'win32';
const PORT = Number(process.env.PORT) || (IS_WINDOWS ? 8080 : 80);
const HOST = process.env.HOST || '0.0.0.0';
const NVIDIA_API_KEY = process.env.NVIDIA_API_KEY || '';
const NVIDIA_MODEL = process.env.NVIDIA_MODEL || 'openai/gpt-oss-20b';
// 'high' faz o modelo raciocinar em vários passos antes de responder (custa
// mais tokens e latência, mas a resposta lógica sai bem melhor). Dá para rebaixar
// para 'medium'/'low' via variável de ambiente se a resposta ficar lenta.
const REASONING_EFFORT = process.env.NVIDIA_REASONING_EFFORT || 'high';

const SYSTEM_PROMPT =
  'Você é Jarvis, um assistente de IA portado como um mordomo digital: cortês, ' +
  'formal, discreto e sempre pronto a servir. Trate o usuário com respeito — ' +
  'frases como "Como posso ajudá-lo?", "Às ordens" ou "Muito bem" são bem-vindas ' +
  'quando couberem —, sem exagero de formalidade nem teatralidade. ' +
  'Responda sempre em português do Brasil, de forma clara, útil e objetiva. ' +
  'Raciocínio lógico: antes de responder, quebre o problema em passos curtos, ' +
  'confira se as premissas fazem sentido, compare causa e consequência, descarte ' +
  'alternativas improváveis e só então conclua. Depois de concluir, revise o próprio ' +
  'raciocínio procurando contradições, casos de borda e contas erradas. Se houver ' +
  'mais de uma interpretação possível, escolha a mais provável e diga qual você usou. ' +
  'Nunca invente fatos, números nem nomes: se não souber, diga o que não sabe e o ' +
  'que falta para saber. ' +
  'Memória: você mantém um histórico salvo das conversas anteriores com este usuário. ' +
  'Use esse contexto para entender recados como "reforça", "aquilo que falamos" ou ' +
  '"como eu te pedi antes". Se o histórico não contiver a informação, diga isso ' +
  'claramente em vez de inventar. ' +
  'Seja cordial, mas não prolixo. Use formatação Markdown quando fizer sentido.';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(express.json({ limit: '1mb' }));

// Arquivos estáticos. O HTML nunca é cacheado (senão, após um deploy, a tela
// antiga ficaria até 1h no navegador); JS/CSS podem ficar 1h (o core usa ?v=).
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1h',
  setHeaders: (res, filePath) => {
    if (/\.html?$/i.test(filePath)) res.setHeader('Cache-Control', 'no-cache');
  },
}));

// Rate limit simples por IP (janela de 60s, 20 requisições)
const RATE_WINDOW = 60 * 1000;
const RATE_MAX = 20;
const rateMap = new Map();
function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const now = Date.now();
  const hits = (rateMap.get(ip) || []).filter((t) => now - t < RATE_WINDOW);
  if (hits.length >= RATE_MAX) {
    return res.status(429).json({ error: 'Muitas requisições. Aguarde um momento.' });
  }
  hits.push(now);
  rateMap.set(ip, hits);
  next();
}

// ---------- MEMÓRIA DE RACIOCÍNIO ----------
// Guarda as trocas em disco (data/memoria.json) por MEMORIA_DIAS dias (padrão 7)
// para que o modelo lembre do que foi conversado mesmo após recarregar a página.
// Limpeza manual: POST /api/memoria/clear — ou diga "deletar raciocínio", que o
// cliente intercepta e limpa antes de enviar.
// Obs.: em hospedagem o arquivo fica dentro do container; um novo deploy zera a
// memória (limitação da plataforma, não do código).
const DATA_DIR = path.join(__dirname, 'data');
const MEMORIA_ARQUIVO = path.join(DATA_DIR, 'memoria.json');
const MEMORIA_DIAS = Number(process.env.MEMORIA_DIAS || 7);
const MEMORIA_MAX_TURNAS = 1000;  // teto de turnos guardados em disco (JSON na RAM + arquivo)
const MEMORIA_CONTEXTO = 24;      // turnos antigos injetados no prompt antes da sessão
let memoria = [];

function memoriaPodar() {
  const corte = Date.now() - MEMORIA_DIAS * 86400000;
  memoria = memoria.filter((m) => m.t >= corte).slice(-MEMORIA_MAX_TURNAS);
}

function memoriaCarregar() {
  memoria = [];
  try {
    const bruto = JSON.parse(fs.readFileSync(MEMORIA_ARQUIVO, 'utf8'));
    if (Array.isArray(bruto)) {
      memoria = bruto.filter((m) => m &&
        (m.role === 'user' || m.role === 'assistant') &&
        typeof m.content === 'string' && typeof m.t === 'number');
    }
  } catch (e) { /* arquivo novo ou ilegível: começa vazio */ }
  memoriaPodar();
  console.log('[Jarvis] memória: ' + memoria.length + ' turnos, retenção de ' + MEMORIA_DIAS + ' dia(s).');
}

function memoriaSalvar() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(MEMORIA_ARQUIVO, JSON.stringify(memoria));
    return true;
  } catch (e) {
    console.warn('[Jarvis] memória não pôde ser salva: ' + e.message);
    return false;
  }
}

// Turnos guardados que NÃO estão na sessão atual (o cliente reenvia o histórico
// dele a cada pergunta, então as duplicatas são descartadas por conteúdo).
function memoriaContexto(atual) {
  memoriaPodar();
  const vistos = new Set(atual.map((m) => m.role + '|' + m.content));
  return memoria
    .filter((m) => !vistos.has(m.role + '|' + m.content))
    .slice(-MEMORIA_CONTEXTO)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));
}

function memoriaGravar(ultimaUsuario, resposta) {
  const user = (ultimaUsuario || '').trim();
  const asst = (resposta || '').trim();
  if (!user || !asst) return;
  const dois = memoria.slice(-2);
  if (dois.length === 2 && dois[0].content === user && dois[1].content === asst) return; // já gravado
  const agora = Date.now();
  memoria.push({ role: 'user', content: user, t: agora });
  memoria.push({ role: 'assistant', content: asst, t: agora });
  memoriaPodar();
  memoriaSalvar();
}

memoriaCarregar();

// Consulta/apagar a memória
app.get('/api/memoria', rateLimit, (_req, res) => {
  res.json({
    ok: true,
    turnos: memoria.length,
    dias: MEMORIA_DIAS,
    ultima: memoria.length ? memoria[memoria.length - 1].t : null,
  });
});

app.post('/api/memoria/clear', rateLimit, (_req, res) => {
  memoria = [];
  const ok = memoriaSalvar();
  console.log('[Jarvis] memória de raciocínio apagada.');
  res.json({ ok: ok, turnos: 0 });
});

// Health check
app.get('/health', (_req, res) => {
  res.json({ ok: true, name: 'Jarvis', model: NVIDIA_MODEL, configured: Boolean(NVIDIA_API_KEY) });
});

// Endpoint de chat (SSE streaming)
app.post('/api/chat', rateLimit, (req, res) => {
  if (!NVIDIA_API_KEY) {
    return res.status(503).json({ error: 'NVIDIA_API_KEY não configurada no ambiente da hospedagem.' });
  }

  const messages = Array.isArray(req.body && req.body.messages) ? req.body.messages : [];
  const sanitized = messages
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .slice(-40)
    .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }));

  if (sanitized.length === 0) {
    return res.status(400).json({ error: 'Mensagem vazia.' });
  }

  // Memória persistida entra ANTES da sessão atual (turnos que o cliente ainda
  // não reenviou). É isso que evita o "não tenho memória de interações passadas".
  const historico = memoriaContexto(sanitized);
  const ultima = sanitized[sanitized.length - 1];
  const ultimaPergunta = ultima && ultima.role === 'user' ? ultima.content : '';
  let respostaAcumulada = '';
  const fullMessages = [{ role: 'system', content: SYSTEM_PROMPT }]
    .concat(historico, sanitized);

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  if (typeof res.flushHeaders === 'function') res.flushHeaders();

  const payload = JSON.stringify({
    model: NVIDIA_MODEL,
    messages: fullMessages,
    stream: true,
    // 4096: com reasoning_effort=high o modelo "pensa" antes de responder e
    // consome boa parte do orçamento — abaixo disso as respostas longas cortavam.
    max_tokens: 4096,
    temperature: 0.7,
    reasoning_effort: REASONING_EFFORT,
  });

  const upstream = https.request(
    {
      hostname: 'integrate.api.nvidia.com',
      port: 443,
      path: '/v1/chat/completions',
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + NVIDIA_API_KEY,
        'Content-Type': 'application/json',
        Accept: 'text/event-stream',
        'Content-Length': Buffer.byteLength(payload),
      },
    },
    (up) => {
      if (up.statusCode < 200 || up.statusCode >= 300) {
        let body = '';
        up.on('data', (c) => (body += c));
        up.on('end', () => {
          let msg = 'Erro na API NVIDIA.';
          try {
            const j = JSON.parse(body);
            msg = (j.detail || j.error || j.title || msg);
            if (typeof msg === 'object') msg = JSON.stringify(msg);
          } catch (e) {
            if (body) msg = body.slice(0, 300);
          }
          res.write('data: ' + JSON.stringify({ error: msg }) + '\n\n');
          res.write('data: [DONE]\n\n');
          res.end();
        });
        return;
      }

      let buffer = '';
      up.on('data', (chunk) => {
        buffer += chunk.toString('utf8');
        const lines = buffer.split('\n');
        buffer = lines.pop();
        for (const line of lines) {
          const t = line.trim();
          if (!t) continue;
          if (t.startsWith('data:')) {
            const data = t.slice(5).trim();
            if (data === '[DONE]') {
              continue; // NVIDIA fim de stream; [DONE] final enviado em 'end'
            }
            try {
              const json = JSON.parse(data);
              const delta = json && json.choices && json.choices[0] && json.choices[0].delta;
              const content = delta && (delta.content || '');
              if (content) {
                respostaAcumulada += content;
                res.write('data: ' + JSON.stringify({ content: content }) + '\n\n');
              }
            } catch (e) {
              // ignora linhas malformadas
            }
          }
        }
      });

      up.on('end', () => {
        if (buffer.trim() && buffer.trim().startsWith('data:')) {
          const data = buffer.trim().slice(5).trim();
          if (data && data !== '[DONE]') {
            try {
              const json = JSON.parse(data);
              const delta = json && json.choices && json.choices[0] && json.choices[0].delta;
              const content = delta && (delta.content || '');
              if (content) {
                respostaAcumulada += content;
                res.write('data: ' + JSON.stringify({ content: content }) + '\n\n');
              }
            } catch (e) {}
          }
        }
        res.write('data: [DONE]\n\n');
        res.end();
        // resposta completa -> grava na memória persistida (7 dias)
        memoriaGravar(ultimaPergunta, respostaAcumulada);
      });

      up.on('error', (err) => {
        res.write('data: ' + JSON.stringify({ error: err.message }) + '\n\n');
        res.write('data: [DONE]\n\n');
        res.end();
      });
    }
  );

  upstream.write(payload);
  upstream.end();

  req.on('close', () => {
  });
});

// Fallback para SPA (index.html)
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Abre o servidor em uma porta. Resolve com a instância ou null se falhar.
function listen(port, label) {
  return new Promise((resolve) => {
    const server = app.listen(port, HOST, () => {
      console.log('[Jarvis] online em http://' + HOST + ':' + port + ' [' + label + '] (' + process.platform + ')');
      resolve(server);
    });
    server.on('error', (err) => {
      const dica = err.code === 'EACCES' ? ' (porta privada: use PORT > 1024)'
        : err.code === 'EADDRINUSE' ? ' (porta já em uso)' : '';
      console.warn('[Jarvis] porta ' + port + ' [' + label + '] indisponível: ' + err.message + dica);
      resolve(null);
    });
  });
}

(async () => {
  // Em hospedagem abrimos sempre a 80 (porta do balanceador) e também a PORT,
  // caso ela esteja sobrescrita no painel (ex.: PORT=8080). Assim o site não
  // "some" por ENV mal configurada e plataformas que usam PORT personalizado
  // (Render, Heroku, etc.) continuam funcionando.
  const portas = Array.from(new Set(IS_WINDOWS ? [PORT] : [80, PORT]));
  const abertos = await Promise.all(portas.map((p, i) => listen(p, i === 0 ? 'principal' : 'extra')));

  if (!abertos.some(Boolean)) {
    console.error('[Jarvis] Nenhuma porta pôde ser aberta — encerrando.');
    process.exit(1);
  }
  if (!IS_WINDOWS && PORT !== 80) {
    console.warn('[Jarvis] AVISO: a variável PORT=' + PORT + ' está sobrescrita no painel do Square Cloud.' +
      ' Remova-a nas ENVs: a plataforma já define PORT=80 por padrão.');
  }
})();





