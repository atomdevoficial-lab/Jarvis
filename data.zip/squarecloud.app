﻿MAIN=server.js
MEMORY=512
VERSION=recommended
DISPLAY_NAME=Jarvis IA
DESCRIPTION=Chat de IA Jarvis alimentado pela API NVIDIA NIM
SUBDOMAIN=jarvis-ia-nvidia
AUTORESTART=true
START=npm start
