/*!
 * Jarvis Core — núcleo neural reativo
 * Esfera 3D de partículas e conexões que reage ao estado REAL do assistente
 * e ao áudio real do microfone / da síntese de voz.
 *
 * Sem dependências externas: Canvas 2D + projeção 3D manual + Web Audio API.
 *
 * Estados:
 *   idle       -> aguardando comando (giro lento, cintilação suave)
 *   listening  -> escutando (reage ao volume do microfone em tempo real)
 *   processing -> processando (contração, giro rápido, ondas e pulsos)
 *   speaking   -> respondendo (reage à síntese de voz / à chegada do texto)
 */
(function (global) {
  'use strict';

  /* ================================================================
   * 1. RUÍDO 3D (value noise + fbm) — usado para tornar a esfera
   *    irregular, orgânica e não perfeitamente geométrica.
   * ================================================================ */
  function fade(t) { return t * t * (3 - 2 * t); }

  function hash3(i, j, k) {
    var n = (Math.imul(i, 374761393) + Math.imul(j, 668265263) + Math.imul(k, 1274126177)) | 0;
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    n = n ^ (n >>> 16);
    return (n >>> 0) / 4294967296;
  }

  function noise3(x, y, z) {
    var xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
    var u = fade(x - xi), v = fade(y - yi), w = fade(z - zi);
    var c000 = hash3(xi, yi, zi),     c100 = hash3(xi + 1, yi, zi);
    var c010 = hash3(xi, yi + 1, zi), c110 = hash3(xi + 1, yi + 1, zi);
    var c001 = hash3(xi, yi, zi + 1), c101 = hash3(xi + 1, yi, zi + 1);
    var c011 = hash3(xi, yi + 1, zi + 1), c111 = hash3(xi + 1, yi + 1, zi + 1);
    var x00 = c000 + (c100 - c000) * u, x10 = c010 + (c110 - c010) * u;
    var x01 = c001 + (c101 - c001) * u, x11 = c011 + (c111 - c011) * u;
    var y0 = x00 + (x10 - x00) * v, y1 = x01 + (x11 - x01) * v;
    return y0 + (y1 - y0) * w;
  }

  function fbm(x, y, z) {
    return noise3(x, y, z) * 0.55 +
           noise3(x * 2.03 + 7.1, y * 2.03 - 3.7, z * 2.03 + 1.9) * 0.30 +
           noise3(x * 4.11 - 2.2, y * 4.11 + 5.5, z * 4.11 - 1.3) * 0.15;
  }

  /* ================================================================
   * 2. PARÂMETROS VISUAIS DE CADA ESTADO
   * ================================================================ */
  var STATES = {
    idle: {
      label: 'AGUARDANDO PRÓXIMO COMANDO…',
      rot: 0.13, scale: 1.00, deform: 0.055, gain: 0.30,
      edge: 0.60, twinkle: 1.00, wave: 0.0, pulses: 0
    },
    listening: {
      label: 'ESCUTANDO…',
      rot: 0.17, scale: 1.00, deform: 0.075, gain: 1.00,
      edge: 0.88, twinkle: 1.45, wave: 0.0, pulses: 0
    },
    processing: {
      label: 'PROCESSANDO…',
      rot: 0.80, scale: 0.88, deform: 0.105, gain: 0.00,
      edge: 1.25, twinkle: 1.75, wave: 1.0, pulses: 5
    },
    speaking: {
      label: 'RESPONDENDO…',
      rot: 0.26, scale: 1.03, deform: 0.085, gain: 0.00,
      edge: 1.00, twinkle: 1.50, wave: 0.35, pulses: 2
    }
  };

  var BUCKETS = 6;          // faixas de opacidade das linhas
  var ALPHA_MAX = 0.55;     // opacidade máxima de uma linha
  var FOV = 3.0;            // distância de projeção

  /* ================================================================
   * 3. CRIAÇÃO DO NÚCLEO
   * ================================================================ */
  function create(opts) {
    opts = opts || {};
    var canvas = opts.canvas;
    var label = opts.label || null;
    if (!canvas || !canvas.getContext) return null;

    var ctx = canvas.getContext('2d');
    if (!ctx) return null;

    /* ---------------- estado ---------------- */
    var state = 'idle';
    var W = 0, H = 0, dpr = 1, cx = 0, cy = 0, R = 200;
    var dprScale = 1;

    var cur = { rot: 0.13, scale: 1, deform: 0.055, gain: 0.3, edge: 0.45, twinkle: 1, wave: 0, pulses: 0 };

    var t = 0;                 // tempo decorrido (s)
    var last = 0;
    var raf = 0;
    var tick = 0;
    var ay = 0;                // rotação Y
    var ax = -0.16;            // rotação X (inclinación sutil)

    var energy = 0;            // energia combinada 0..~1.4
    var micLevel = 0;          // volume real do microfone
    var micBright = 0;         // brilho (frequências altas) do microfone
    var speechEnv = 0;         // envelope da síntese de voz
    var procEnv = 0;           // pulso interno do processamento
    var wavePhase = 0;

    /* ---------------- geometria ---------------- */
    var P = 0;                 // total de partículas
    var quality = 1;           // qualidade adaptativa
    var activeN = 0;           // partículas realmente desenhadas
    var baseX, baseY, baseZ, dirX, dirY, dirZ;
    var phase, psize, pbright, dist;
    var px, py, pdep, psc;

    var E = 0;
    var edgeA, edgeB, edgeType, edgeBase, edgeLen;
    var bucketOf, bucketIdx, bucketFill, bucketOffset;

    /* ---------------- pulsos viajando nas linhas ---------------- */
    var pulseList = [];
    for (var pi = 0; pi < 8; pi++) pulseList.push({ e: 0, t: 0, sp: 0, on: false });

    /* ---------------- áudio ---------------- */
    var externalProvider = null;      // fn -> AnalyserNode|null (modo mãos-livres)
    var pushAnalyser = null;          // analyser próprio (push-to-talk)
    var pushCtx = null, pushStream = null;
    var wantCapture = false, captureDelay = 0;
    var bufT = null, bufF = null, bufFSize = -1;

    /* ---------------- sprite de partícula ---------------- */
    var sprite = document.createElement('canvas');
    sprite.width = sprite.height = 64;
    (function paintSprite() {
      var g = sprite.getContext('2d');
      var grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      grd.addColorStop(0.00, 'rgba(255,255,255,1)');
      grd.addColorStop(0.22, 'rgba(255,255,255,0.95)');
      grd.addColorStop(0.40, 'rgba(255,255,255,0.45)');
      grd.addColorStop(0.68, 'rgba(255,255,255,0.12)');
      grd.addColorStop(1.00, 'rgba(255,255,255,0)');
      g.fillStyle = grd;
      g.fillRect(0, 0, 64, 64);
    })();

    var lineStyles = [];
    for (var bi = 0; bi < BUCKETS; bi++) {
      var a = ((bi + 0.55) / BUCKETS) * ALPHA_MAX;
      lineStyles.push('rgba(255,255,255,' + a.toFixed(3) + ')');
    }
    var bucketCount = new Int32Array(BUCKETS);

    /* ================================================================
     * GEOMETRIA DA ESFERA
     * ================================================================ */
    function buildParticles(n) {
      P = n;
      baseX = new Float32Array(P); baseY = new Float32Array(P); baseZ = new Float32Array(P);
      dirX = new Float32Array(P); dirY = new Float32Array(P); dirZ = new Float32Array(P);
      phase = new Float32Array(P); psize = new Float32Array(P);
      pbright = new Float32Array(P); dist = new Float32Array(P);
      px = new Float32Array(P); py = new Float32Array(P);
      pdep = new Float32Array(P); psc = new Float32Array(P);

      var golden = Math.PI * (3 - Math.sqrt(5));
      for (var i = 0; i < P; i++) {
        // distribuição uniforme na esfera (sequência de Fibonacci)
        var yy = P === 1 ? 0 : 1 - (i / (P - 1)) * 2;
        var rr = Math.sqrt(Math.max(0, 1 - yy * yy));
        var th = golden * i;
        var dx = Math.cos(th) * rr, dz = Math.sin(th) * rr, dy = yy;

        var rad;
        if (i % 5 === 3) {
          // núcleo interno -> densidades diferentes, profundidade real
          rad = 0.16 + 0.56 * fbm(dx * 2.4 - 8.1, dy * 2.4 - 8.1, dz * 2.4 - 8.1);
        } else {
          // casca irregular guiada por ruído (lobos e deformações)
          var n1 = fbm(dx * 1.02 + 4.7, dy * 1.02 + 4.7, dz * 1.02 + 4.7);
          rad = 0.74 + (n1 - 0.5) * 0.95;
        }
        rad *= 0.93 + 0.14 * hash3(i + 1, 3, 9);   // jitter
        if (rad < 0.10) rad = 0.10;

        var x = dx * rad, y = dy * rad, z = dz * rad;
        baseX[i] = x; baseY[i] = y; baseZ[i] = z;

        var l = Math.sqrt(x * x + y * y + z * z) || 1;
        dirX[i] = x / l; dirY[i] = y / l; dirZ[i] = z / l;
        dist[i] = l;

        phase[i] = hash3(i + 11, 5, 2) * Math.PI * 2;
        var hs = hash3(i + 7, 1, 4);
        psize[i] = 0.65 + 1.75 * hs * hs;                       // poucas grandes, muitas pequenas
        pbright[i] = 0.32 + 0.68 * Math.pow(hash3(i + 3, 9, 6), 0.8);
      }
      activeN = P;
    }

    function buildEdges() {
      var key = {}, list = [];
      var i, j, k;

      // 3 vizinhos mais próximos por partícula (topologia de rede neural)
      for (i = 0; i < P; i++) {
        var bx = baseX[i], by = baseY[i], bz = baseZ[i];
        var n1 = -1, n2 = -1, n3 = -1, d1 = 1e9, d2 = 1e9, d3 = 1e9;
        for (j = 0; j < P; j++) {
          if (j === i) continue;
          var ddx = baseX[j] - bx, ddy = baseY[j] - by, ddz = baseZ[j] - bz;
          var d = ddx * ddx + ddy * ddy + ddz * ddz;
          if (d < d1) { d3 = d2; n3 = n2; d2 = d1; n2 = n1; d1 = d; n1 = j; }
          else if (d < d2) { d3 = d2; n3 = n2; d2 = d; n2 = j; }
          else if (d < d3) { d3 = d; n3 = j; }
        }
        var cand = [n1, n2, n3];
        for (k = 0; k < 3; k++) {
          var v = cand[k];
          if (v < 0) continue;
          var a = Math.min(i, v), b = Math.max(i, v);
          var id = a * 100000 + b;
          if (key[id]) continue;
          key[id] = 1;
          list.push([a, b, 0]);
        }
      }

      // "cordas" cruzando o interior -> linhas que se cruzam, complexidade
      var chords = Math.round(P * 0.26);
      for (i = 0; i < chords; i++) {
        var a2 = Math.floor(hash3(i + 1, 77, 3) * P) % P;
        var b2 = Math.floor(hash3(i + 1, 33, 7) * P) % P;
        if (a2 === b2) continue;
        var lo = Math.min(a2, b2), hi = Math.max(a2, b2);
        var id2 = lo * 100000 + hi;
        if (key[id2]) continue;
        var vx = baseX[a2] - baseX[b2], vy = baseY[a2] - baseY[b2], vz = baseZ[a2] - baseZ[b2];
        if (vx * vx + vy * vy + vz * vz < 0.20) continue;   // só cordas longas
        key[id2] = 1;
        list.push([lo, hi, 1]);
      }

      E = list.length;
      edgeA = new Int32Array(E); edgeB = new Int32Array(E);
      edgeType = new Uint8Array(E);
      edgeBase = new Float32Array(E); edgeLen = new Float32Array(E);
      bucketOf = new Int32Array(E);
      bucketIdx = new Int32Array(E);
      bucketFill = new Int32Array(BUCKETS);
      bucketOffset = new Int32Array(BUCKETS);

      for (i = 0; i < E; i++) {
        var e = list[i], a3 = e[0], b3 = e[1];
        edgeA[i] = a3; edgeB[i] = b3; edgeType[i] = e[2];
        var dx2 = baseX[a3] - baseX[b3], dy2 = baseY[a3] - baseY[b3], dz2 = baseZ[a3] - baseZ[b3];
        var len = Math.sqrt(dx2 * dx2 + dy2 * dy2 + dz2 * dz2);
        edgeLen[i] = len;
        edgeBase[i] = e[2] ? 0.17 + 0.09 * hash3(i, 4, 8)
                           : 0.36 + 0.28 * (1 - Math.min(1, len / 0.55));
      }
    }

    /* ================================================================
     * TAMANHO / RESOLUÇÃO
     * ================================================================ */
    function resize() {
      dpr = Math.min(global.devicePixelRatio || 1, 2) * dprScale;
      W = canvas.clientWidth || canvas.parentNode.clientWidth || global.innerWidth;
      H = canvas.clientHeight || global.innerHeight;
      canvas.width = Math.max(1, Math.round(W * dpr));
      canvas.height = Math.max(1, Math.round(H * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      cx = W / 2;
      cy = H / 2;
      var narrow = W < 720 && W < H;
      R = Math.min(W, H) * (narrow ? 0.37 : 0.31);
      R = Math.max(110, Math.min(R, H * 0.38, 480));
      positionLabel();
    }

    // rótulo de estado: fica ACIMA da esfera. A tela agora é só o núcleo +
    // a legenda de resposta embaixo, então o espaço superior é livre.
    function positionLabel() {
      if (!label) return;
      var top = H / 2 - R - 34;
      var min = 16, max = H - 40;
      if (typeof opts.getBounds === 'function') {
        try {
          var b = opts.getBounds();
          if (b && isFinite(b.min) && isFinite(b.max) && b.max > b.min) { min = b.min; max = b.max; }
        } catch (e) {}
      }
      if (top > max) top = max;
      if (top < min) top = min;
      label.style.top = Math.round(top) + 'px';
    }

    /* ================================================================
     * ÁUDIO REAL
     * ================================================================ */
    function currentAnalyser() {
      if (pushAnalyser) return pushAnalyser;
      if (externalProvider) {
        try { return externalProvider() || null; } catch (e) { return null; }
      }
      return null;
    }

    function readAudio(dt) {
      var an = currentAnalyser();
      if (!an) {
        // sem microfone -> decai suavemente até zero (nunca inventa movimento)
        var k0 = 1 - Math.exp(-dt * 6);
        micLevel += (0 - micLevel) * k0;
        micBright += (0 - micBright) * k0;
        return;
      }
      if (an.fftSize !== bufFSize) {
        bufFSize = an.fftSize;
        bufT = new Uint8Array(an.fftSize);
        bufF = new Uint8Array(an.frequencyBinCount);
      }
      an.getByteTimeDomainData(bufT);
      var sum = 0;
      for (var i = 0; i < bufT.length; i++) {
        var c = (bufT[i] - 128) / 128;
        sum += c * c;
      }
      var rms = Math.sqrt(sum / bufT.length);
      var raw = Math.min(1, rms * 3.4);

      an.getByteFrequencyData(bufF);
      var hi = 0, hn = 0;
      for (var h = Math.floor(bufF.length * 0.45); h < bufF.length; h++) { hi += bufF[h]; hn++; }
      var rawB = hn ? (hi / hn) / 255 : 0;

      // ataque rápido / solta lento -> reação sem atraso perceptível
      micLevel += (raw - micLevel) * (1 - Math.exp(-dt * (raw > micLevel ? 26 : 8)));
      micBright += (rawB - micBright) * (1 - Math.exp(-dt * (raw > micLevel ? 18 : 6)));
    }

    /* ================================================================
     * PASSO DE ANIMAÇÃO
     * ================================================================ */
    function step(dt) {
      var target = STATES[state] || STATES.idle;
      var k = 1 - Math.exp(-dt * 4.2);
      cur.rot += (target.rot - cur.rot) * k;
      cur.scale += (target.scale - cur.scale) * k;
      cur.deform += (target.deform - cur.deform) * k;
      cur.gain += (target.gain - cur.gain) * k;
      cur.edge += (target.edge - cur.edge) * k;
      cur.twinkle += (target.twinkle - cur.twinkle) * k;
      cur.wave += (target.wave - cur.wave) * k;
      cur.pulses += (target.pulses - cur.pulses) * (1 - Math.exp(-dt * 3));

      // envelope de energia: qual é a fonte REAL neste estado?
      var src;
      if (state === 'speaking') src = speechEnv;
      else if (state === 'processing') src = 0.30 + procEnv;
      else src = micLevel * cur.gain;
      energy += (src - energy) * (1 - Math.exp(-dt * (src > energy ? 22 : 6.5)));

      speechEnv *= Math.exp(-dt * 6.2);
      if (speechEnv < 0.001) speechEnv = 0;

      procEnv = state === 'processing'
        ? 0.5 + 0.5 * Math.sin(wavePhase)
        : 0;

      wavePhase += dt * (state === 'processing' ? 7.5 : 2.2);

      // rotação orgânica: lenta e contínua, acelera com energia/processamento
      var speed = cur.rot * (1 + energy * 0.55);
      ay += dt * speed;
      ax = -0.16 + 0.09 * Math.sin(t * 0.21) + 0.05 * Math.sin(t * 0.07);
    }

    /* ================================================================
     * DESENHO
     * ================================================================ */
    function draw(dt) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';

      var breathe = 1 + 0.022 * Math.sin(t * 1.05) + energy * 0.115;
      var s = cur.scale * breathe;
      var deformAmp = cur.deform + energy * 0.145;
      var vib = energy * 0.045;
      var waveAmt = cur.wave;

      // brilho central (núcleo)
      var coreA = 0.075 + energy * 0.13;
      var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.35);
      g.addColorStop(0, 'rgba(255,255,255,' + coreA.toFixed(3) + ')');
      g.addColorStop(0.5, 'rgba(255,255,255,' + (coreA * 0.35).toFixed(3) + ')');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 1.35, 0, Math.PI * 2);
      ctx.fill();

      var ca = Math.cos(ay), sa = Math.sin(ay);
      var cb = Math.cos(ax), sb = Math.sin(ax);
      var n = activeN;

      // ---- projeção de todas as partículas ----
      for (var i = 0; i < n; i++) {
        var ph = phase[i];
        var d = 1 +
          (Math.sin(t * 1.25 + ph) * 0.55 + Math.sin(t * 0.63 + ph * 2.7) * 0.45) * deformAmp +
          (waveAmt ? Math.sin(dist[i] * 11 - wavePhase) * 0.055 * waveAmt : 0);

        var x = baseX[i] * d, y = baseY[i] * d, z = baseZ[i] * d;

        // vibração ligada ao volume real da voz
        if (vib > 0.0005) {
          x += Math.sin(t * 13.3 + ph * 3.1) * vib;
          y += Math.sin(t * 16.7 + ph * 1.7) * vib;
          z += Math.cos(t * 11.9 + ph * 2.3) * vib;
        }

        // rotação Y
        var x1 = x * ca + z * sa;
        var z1 = -x * sa + z * ca;
        // rotação X
        var y1 = y * cb - z1 * sb;
        var z2 = y * sb + z1 * cb;

        var persp = FOV / (FOV + z2);
        px[i] = cx + x1 * persp * R * s;
        py[i] = cy + y1 * persp * R * s;
        pdep[i] = (z2 + 1.35) / 2.7;
        psc[i] = persp;
      }

      // ---- linhas (agrupadas em faixas de opacidade p/ desempenho) ----
      for (var b = 0; b < BUCKETS; b++) bucketCount[b] = 0;
      var lineW = 0.62 + energy * 0.30;

      // passo 1: classifica cada linha em uma faixa de opacidade (-1 = descartada)
      for (var e = 0; e < E; e++) {
        bucketOf[e] = -1;
        var a1 = edgeA[e], b1 = edgeB[e];
        if (a1 >= n || b1 >= n) continue;

        var ex = px[a1] - px[b1], ey = py[a1] - py[b1];
        var curLen = Math.sqrt(ex * ex + ey * ey);
        var restLen = edgeLen[e] * R * s;
        if (restLen < 1) continue;
        var stretch = curLen / restLen;
        if (stretch > 2.2) continue;                       // linha "desaparece" quando estica demais
        var fadeLen = 1 - Math.min(0.92, (stretch - 1) / 1.5);

        var depth = (pdep[a1] + pdep[b1]) * 0.5;
        var tw = 0.62 + 0.38 * Math.sin(t * 1.9 + (a1 + b1) * 0.7);
        var alpha = edgeBase[e] * cur.edge * (0.55 + 0.75 * depth) * tw * fadeLen *
                    (0.85 + energy * 0.5 + micBright * (state === 'listening' ? 0.55 : 0));
        if (alpha <= 0.006) continue;

        var idx = (alpha / ALPHA_MAX * BUCKETS) | 0;
        if (idx >= BUCKETS) idx = BUCKETS - 1;
        if (idx < 0) idx = 0;
        bucketOf[e] = idx;
        bucketCount[idx]++;
      }

      // passo 2: offsets contíguos + preenchimento
      var acc = 0;
      for (var b2 = 0; b2 < BUCKETS; b2++) {
        bucketOffset[b2] = acc;
        bucketFill[b2] = acc;
        acc += bucketCount[b2];
      }
      for (var e2 = 0; e2 < E; e2++) {
        var idb = bucketOf[e2];
        if (idb < 0) continue;
        bucketIdx[bucketFill[idb]++] = e2;
      }

      // passo 3: um stroke por faixa (mudança mínima de estado no canvas)
      for (var bi2 = 0; bi2 < BUCKETS; bi2++) {
        var count = bucketCount[bi2];
        if (!count) continue;
        ctx.strokeStyle = lineStyles[bi2];
        ctx.lineWidth = lineW;
        ctx.beginPath();
        var off = bucketOffset[bi2];
        for (var q = 0; q < count; q++) {
          var ee = bucketIdx[off + q];
          var aa = edgeA[ee], bb = edgeB[ee];
          ctx.moveTo(px[aa], py[aa]);
          ctx.lineTo(px[bb], py[bb]);
        }
        ctx.stroke();
      }

      // ---- pulsos luminosos percorrendo as conexões ----
      var want = Math.round(cur.pulses);
      for (var p = 0; p < pulseList.length; p++) {
        var pl = pulseList[p];
        if (p < want) {
          if (!pl.on) {
            pl.on = true;
            pl.e = (Math.random() * E) | 0;
            pl.t = 0;
            pl.sp = 0.7 + Math.random() * 0.9;
          }
          pl.t += dt * pl.sp;
          if (pl.t >= 1) { pl.t = 0; pl.e = (Math.random() * E) | 0; }
        } else {
          pl.on = false;
        }
        if (!pl.on) continue;
        var ea = edgeA[pl.e], eb = edgeB[pl.e];
        if (ea >= n || eb >= n) continue;
        var lx = px[ea] + (px[eb] - px[ea]) * pl.t;
        var ly = py[ea] + (py[eb] - py[ea]) * pl.t;
        var ps = (4.5 + energy * 3) * (0.55 + 0.45 * Math.sin(pl.t * Math.PI));
        ctx.globalAlpha = 0.85;
        ctx.drawImage(sprite, lx - ps, ly - ps, ps * 2, ps * 2);
      }
      ctx.globalAlpha = 1;

      // ---- partículas ----
      var twinkleBase = cur.twinkle * (1 + micBright * (state === 'listening' ? 0.7 : 0.15));
      for (var j = 0; j < n; j++) {
        var dep = pdep[j];
        if (dep <= 0.02) continue;
        var twk = 0.34 + 0.66 * (0.5 + 0.5 * Math.sin(t * (1.4 + (j % 7) * 0.22) + phase[j]));
        var al = pbright[j] * (0.48 + 0.85 * dep) * Math.min(1.8, twk * twinkleBase);
        if (al <= 0.02) continue;
        var sz = psize[j] * psc[j] * (3.4 + energy * 2.6);
        ctx.globalAlpha = al > 1 ? 1 : al;
        ctx.drawImage(sprite, px[j] - sz, py[j] - sz, sz * 2, sz * 2);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
    }

    // offsets contíguos por faixa dentro de bucketIdx (calculados em draw())

    /* ================================================================
     * MEDIÇÃO DE DESEMPENHO (reduz partículas em aparelhos fracos)
     * ================================================================ */
    var fpsAcc = 0, fpsN = 0, lowStreak = 0, highStreak = 0, warmup = 0;
    function applyQuality() {
      activeN = Math.max(180, Math.floor(P * quality));
    }
    function measure(dt) {
      // aba oculta é limitada pelo navegador -> não conta como desempenho real
      if (dt <= 0 || document.hidden) { fpsAcc = 0; fpsN = 0; return; }
      fpsAcc += 1 / dt;
      fpsN++;
      if (fpsN < 70) return;
      var avg = fpsAcc / fpsN;
      fpsAcc = 0; fpsN = 0;
      warmup++;
      if (warmup < 3) return;                 // ignora o aquecimento (layout, cache, GC)

      if (avg < 42) {                          // máquina lenta -> reduz partículas
        highStreak = 0;
        lowStreak++;
        if (lowStreak >= 2 && quality > 0.42) {
          lowStreak = 0;
          quality = Math.max(0.4, quality * 0.72);
          applyQuality();
          if (quality <= 0.55 && dprScale > 0.7) { dprScale = 0.7; resize(); }
        }
      } else if (avg > 56) {                   // sobrou desempenho -> recupera
        lowStreak = 0;
        highStreak++;
        if (highStreak >= 4 && quality < 1) {
          highStreak = 0;
          quality = Math.min(1, quality * 1.18);
          applyQuality();
          if (quality > 0.72 && dprScale < 1) { dprScale = 1; resize(); }
        }
      } else {
        lowStreak = 0;
        highStreak = 0;
      }
    }

    /* ================================================================
     * LOOP
     * ================================================================ */
    function frame(now) {
      raf = requestAnimationFrame(frame);
      var dt = last ? Math.min(0.05, (now - last) / 1000) : 0.016;
      last = now;
      t += dt;
      tick++;
      if (tick % 45 === 1) positionLabel();   // acompanha mudanças de altura do compositor
      try {
        readAudio(dt);
        step(dt);
        draw(dt);
        measure(dt);
      } catch (err) {
        cancelAnimationFrame(raf);
        raf = 0;
        if (global.console) console.error('[JarvisCore]', err);
      }
    }

    /* ================================================================
     * RÓTULO DE ESTADO
     * ================================================================ */
    var labelTimer = 0;
    function setLabel(text) {
      if (!label) return;
      clearTimeout(labelTimer);
      label.style.opacity = '0';
      labelTimer = setTimeout(function () {
        label.textContent = text;
        label.dataset.state = state;
        label.style.opacity = '1';
      }, 170);
    }

    /* ================================================================
     * CAPTURA DE ÁUDIO PRÓPRIA (push-to-talk)
     * ================================================================ */
    function startMicCapture() {
      wantCapture = true;
      if (pushAnalyser) return Promise.resolve(true);
      if (externalProvider) {
        try { if (externalProvider()) return Promise.resolve(true); } catch (e) {}
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return Promise.resolve(false);

      return new Promise(function (resolve) {
        // pequena espera: deixa o reconhecimento de voz garantir o microfone
        clearTimeout(captureDelay);
        captureDelay = setTimeout(function () {
          navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
          }).then(function (stream) {
            if (!wantCapture) {                       // usuário parou antes de termos o stream
              stream.getTracks().forEach(function (tr) { tr.stop(); });
              resolve(false);
              return;
            }
            pushStream = stream;
            pushCtx = new (global.AudioContext || global.webkitAudioContext)();
            if (pushCtx.state === 'suspended') pushCtx.resume();
            var src = pushCtx.createMediaStreamSource(stream);
            pushAnalyser = pushCtx.createAnalyser();
            pushAnalyser.fftSize = 512;
            pushAnalyser.smoothingTimeConstant = 0.65;
            src.connect(pushAnalyser);
            resolve(true);
          }).catch(function () { resolve(false); });
        }, 140);
      });
    }

    function stopMicCapture() {
      wantCapture = false;
      clearTimeout(captureDelay);
      if (pushAnalyser) { pushAnalyser = null; }
      if (pushStream) { pushStream.getTracks().forEach(function (tr) { tr.stop(); }); pushStream = null; }
      if (pushCtx) { try { pushCtx.close(); } catch (e) {} pushCtx = null; }
      bufFSize = -1;
    }

    /* ================================================================
     * INICIALIZAÇÃO
     * ================================================================ */
    // Núcleo mais denso: o dono autorizou usar mais RAM/CPU em troca de
    // definição. A qualidade adaptativa reduz os buckets se a máquina for fraca.
    var baseCount = (global.innerWidth < 720) ? 520
                   : ((navigator.hardwareConcurrency || 8) <= 4 ? 700 : 950);
    buildParticles(baseCount);
    buildEdges();
    resize();

    global.addEventListener('resize', function () {
      clearTimeout(resize._t);
      resize._t = setTimeout(resize, 120);
    });

    raf = requestAnimationFrame(frame);

    /* ================================================================
     * API PÚBLICA
     * ================================================================ */
    var api = {
      states: Object.keys(STATES),

      setState: function (next) {
        if (!STATES[next] || next === state) return;
        state = next;
        setLabel(STATES[next].label);
      },

      getState: function () { return state; },

      // impulso de energia (voz sintetizada por palavra / tokens de texto)
      pulse: function (v) {
        v = typeof v === 'number' ? v : 0.7;
        speechEnv = Math.min(1.5, speechEnv + v);
      },

      setAnalyserProvider: function (fn) { externalProvider = typeof fn === 'function' ? fn : null; },
      startMicCapture: startMicCapture,
      stopMicCapture: stopMicCapture,

      // leituras para depuração / status
      getMicLevel: function () { return micLevel; },
      getEnergy: function () { return energy; },
      getStats: function () {
        return { state: state, quality: +quality.toFixed(2), particles: activeN, edges: E, dpr: +dpr.toFixed(2) };
      },

      destroy: function () {
        if (raf) cancelAnimationFrame(raf);
        raf = 0;
        stopMicCapture();
      }
    };

    if (label) {
      label.textContent = STATES[state].label;
      label.dataset.state = state;
    }

    global.JarvisCore.instance = api;
    return api;
  }

  global.JarvisCore = { create: create, STATES: STATES };
})(window);
